import NXOpen
import NXOpen.UF

def main():
    session = NXOpen.Session.GetSession()
    uf_session = NXOpen.UF.UFSession.GetUFSession()

    print("[DEBUG] uf_session.Std attrs:", [a for a in dir(uf_session.Std) if "stl" in a.lower() or "export" in a.lower()])
    print("[DEBUG] uf_session.Facet attrs:", [a for a in dir(uf_session.Facet) if "stl" in a.lower() or "export" in a.lower() or "facet" in a.lower()])

    try:
        creator = session.DexManager.CreateStlCreator()
        print("[DEBUG] StlCreator attrs:", [a for a in dir(creator) if not a.startswith("_")])
    except Exception as e:
        print(f"[ERROR] StlCreator error: {e}")

if __name__ == "__main__":
    main()
