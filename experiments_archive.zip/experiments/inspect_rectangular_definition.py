import NXOpen
import sys

def main():
    session = NXOpen.Session.GetSession()
    part = session.Parts.NewDisplay("inspect_temp_pattern2.prt", NXOpen.Part.Units.Millimeters)
    try:
        builder = part.Features.CreatePatternFeatureBuilder(NXOpen.Features.Feature.Null)
        service = builder.PatternService
        rect = service.RectangularDefinition
        print("RectangularDefinition properties/methods:")
        for attr in sorted(dir(rect)):
            print("  ", attr)
    finally:
        pass

if __name__ == "__main__":
    main()
