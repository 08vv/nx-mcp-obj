import NXOpen
import sys

def main():
    session = NXOpen.Session.GetSession()
    part = session.Parts.NewDisplay("inspect_temp_pattern.prt", NXOpen.Part.Units.Millimeters)
    try:
        builder = part.Features.CreatePatternFeatureBuilder(NXOpen.Features.Feature.Null)
        service = builder.PatternService
        print("PatternDefinition properties/methods:")
        for attr in sorted(dir(service)):
            print("  ", attr)
    finally:
        pass

if __name__ == "__main__":
    main()
