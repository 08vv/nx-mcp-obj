with open(r"c:\Users\HP\nx-mcp\src\nx_mcp\bridge\nx_bridge.py", "r", encoding="utf-8") as f:
    lines = f.readlines()

for i, line in enumerate(lines):
    if "measure_body_volume" in line or "AskMassProps3d" in line or "ask_mass_props" in line:
        print(f"{i+1}: {line.strip()}")
        # print surrounding lines
        for j in range(max(0, i-5), min(len(lines), i+30)):
            print(f"  {j+1}: {lines[j].strip()}")
        break
