import NXOpen
import sys

def main():
    print("PatternEnum:")
    for attr in dir(NXOpen.GeometricUtilities.PatternDefinition.PatternEnum):
        print("  ", attr)

if __name__ == "__main__":
    main()
