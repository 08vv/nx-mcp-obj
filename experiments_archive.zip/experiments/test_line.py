r"""
test_line.py
"""
import NXOpen

session = NXOpen.Session.GetSession()
work_part = session.Parts.NewDisplay("C:/Users/HP/nx-mcp/test_line.prt", NXOpen.Part.Units.Millimeters)

p1 = NXOpen.Point3d(-7.0, 8.0, 0.0)
p2 = NXOpen.Point3d(-7.0, -8.0, 0.0)

pt1 = work_part.Points.CreatePoint(p1)
pt2 = work_part.Points.CreatePoint(p2)

line = work_part.Curves.CreateLine(pt1, pt2)
print("Created line successfully:", line.Tag)
