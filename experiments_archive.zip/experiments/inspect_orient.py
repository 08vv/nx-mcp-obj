import NXOpen
import sys

def main():
    try:
        session = NXOpen.Session.GetSession()
        part = session.Parts.NewDisplay("temp_orient_inspect.prt", NXOpen.Part.Units.Millimeters)
        
        view = part.ModelingViews.WorkView
        
        # Check help or attributes of view.Orient
        print("view.Orient docs/type:")
        print(type(view.Orient))
        print(view.Orient.__doc__)
        
        # Search NXOpen for CannedOrientation
        print("\nSearching NXOpen for Orientation:")
        for name in dir(NXOpen):
            if "Orientation" in name:
                print(name)
                
        # If NXOpen.View.CannedOrientation exists, let's print its attributes
        if hasattr(NXOpen.View, "CannedOrientation"):
            print("\nNXOpen.View.CannedOrientation values:")
            co = NXOpen.View.CannedOrientation
            for attr in dir(co):
                if not attr.startswith("_"):
                    print(attr)
                    
    except Exception as e:
        print("Error:", e)

if __name__ == "__main__":
    main()
