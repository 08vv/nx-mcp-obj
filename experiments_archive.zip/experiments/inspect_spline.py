import NXOpen
import sys

def main():
    print("All CurveCollection methods:")
    for m in sorted(dir(NXOpen.CurveCollection)):
        print("  ", m)

if __name__ == "__main__":
    main()
