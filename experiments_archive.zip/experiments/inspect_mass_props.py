import NXOpen
import NXOpen.UF
import sys

def main():
    try:
        session = NXOpen.Session.GetSession()
        uf_session = NXOpen.UF.UFSession.GetUFSession()
        
        part = session.Parts.NewDisplay("temp_mass_props.prt", NXOpen.Part.Units.Millimeters)
        
        # Create a simple block
        block_feature_builder = part.Features.CreateBlockFeatureBuilder(NXOpen.Features.Feature.Null)
        block_feature_builder.SetLength("50")
        block_feature_builder.SetWidth("50")
        block_feature_builder.SetHeight("50")
        feat = block_feature_builder.Commit()
        body = feat.GetBodies()[0]
        block_feature_builder.Destroy()
        
        print("Block body created. Tag:", body.Tag)
        
        # Now let's try calling AskMassProps3d
        # uf_session.Modl.AskMassProps3d(body_tags, num_bodies, type, units, accuracy, density, mass_properties)
        # body_tags is an array of body tags
        # type is 1 for solid body properties
        # units is 1 for millimeters (Wait, type is: 1 = solid, units: 1 = mm)
        # accuracy is 0.99 or similar
        # density is 1.0
        # mass_properties is a double array of size 47
        
        body_tags = [body.Tag]
        mass_properties = [0.0] * 47
        
        # Let's check signature of AskMassProps3d
        print("AskMassProps3d signature:")
        print(uf_session.Modl.AskMassProps3d.__doc__)
        
        # Let's call it!
        # uf_session.Modl.AskMassProps3d(body_tags, num_bodies, type, units, accuracy, density, mass_properties)
        # Let's see what arguments it actually takes
        res = uf_session.Modl.AskMassProps3d(body_tags, 1, 1, 1, 0.99, 1, 0.001, mass_properties)
        # Wait, the signature might be different in Python. Let's print the return value and mass_properties.
        print("Return value:", res)
        # The volume of a 50x50x50 block is 125000.0.
        # Let's print the elements of mass_properties
        print("Volume from properties array element 2 or 10?")
        # Usually:
        # mass_properties[2] is Volume
        # mass_properties[3] is Mass
        for i, val in enumerate(mass_properties):
            if val != 0.0:
                print(f"Index {i}: {val}")
                
    except Exception as e:
        print("Error:", e)

if __name__ == "__main__":
    main()
