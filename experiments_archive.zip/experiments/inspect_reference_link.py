import NXOpen
import sys

def main():
    try:
        session = NXOpen.Session.GetSession()
        part, _ = session.Parts.OpenBaseDisplay("dog_leg_link.prt")
        session.Parts.SetWork(part)
        
        print("Features of dog_leg_link.prt:")
        for f in part.Features:
            print(f.GetFeatureName(), f.FeatureType)
            
        print("\nBodies of dog_leg_link.prt:")
        for b in part.Bodies:
            print(f"Name: {b.Name}, Type: {b.BodyType}")
            
    except Exception as e:
        print("Error:", e)

if __name__ == "__main__":
    main()
