r"""
inspect_section.py
"""
import NXOpen
import inspect

session = NXOpen.Session.GetSession()
work_part = session.Parts.NewDisplay("C:/Users/HP/nx-mcp/test_inspect.prt", NXOpen.Part.Units.Millimeters)

section = work_part.Sections.CreateSection(0.001, 0.01, 0.5)
print(doc := getattr(section.AddToSection, "__doc__", None))
