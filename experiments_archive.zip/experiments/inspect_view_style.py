import NXOpen
import sys

def main():
    try:
        session = NXOpen.Session.GetSession()
        part = session.Parts.NewDisplay("temp_inspect.prt", NXOpen.Part.Units.Millimeters)
        
        view = part.ModelingViews.WorkView
        print("View class:", view.__class__.__name__)
        
        # Print all attributes and methods of the view to inspect
        print("View attributes:")
        for attr in dir(view):
            if not attr.startswith("_"):
                print(attr)
                
        # Let's inspect NXOpen.View class rendering options
        print("\nNXOpen.View attributes:")
        for attr in dir(NXOpen.View):
            if not attr.startswith("_"):
                print(attr)
                
        # Let's check if there is an enum for rendering style
        # Print all types in NXOpen that contain 'RenderingStyle' or 'Visualization'
        print("\nSearching NXOpen for RenderingStyle related names:")
        for name in dir(NXOpen):
            if "RenderingStyle" in name or "Visualization" in name or "Display" in name:
                print(name)
                
        # If there's NXOpen.View.RenderingStyleType, let's list its values
        if hasattr(NXOpen.View, "RenderingStyleType"):
            print("\nNXOpen.View.RenderingStyleType values:")
            style_type = NXOpen.View.RenderingStyleType
            for name in dir(style_type):
                if not name.startswith("_"):
                    print(name)
                    
    except Exception as e:
        print("Error:", e)

if __name__ == "__main__":
    main()
