import NXOpen
import NXOpen.UF
import sys

def main():
    try:
        session = NXOpen.Session.GetSession()
        uf_session = NXOpen.UF.UFSession.GetUFSession()
        
        print("Searching uf_session.Modl for mass/props/volume:")
        for attr in dir(uf_session.Modl):
            if "mass" in attr.lower() or "prop" in attr.lower() or "vol" in attr.lower():
                print(f"Modl: {attr}")
                
        print("\nSearching entire uf_session for mass/props/volume:")
        for sub in dir(uf_session):
            obj = getattr(uf_session, sub)
            for attr in dir(obj):
                if "mass" in attr.lower() or "prop" in attr.lower() or "vol" in attr.lower():
                    print(f"{sub}: {attr}")
                    
    except Exception as e:
        print("Error:", e)

if __name__ == "__main__":
    main()
