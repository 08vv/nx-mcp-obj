import NXOpen
import sys

def main():
    session = NXOpen.Session.GetSession()
    part = session.Parts.NewDisplay("inspect_temp2.prt", NXOpen.Part.Units.Millimeters)
    try:
        builder = part.Features.CreateStudioSplineBuilderEx(NXOpen.Features.Feature.Null)
        cm = builder.ConstraintManager
        gcd = cm.CreateGeometricConstraintData()
        print("GeometricConstraintData properties/methods:")
        for attr in sorted(dir(gcd)):
            print("  ", attr)
    finally:
        pass

if __name__ == "__main__":
    main()
