import NXOpen
import NXOpen.UF

def main():
    uf_session = NXOpen.UF.UFSession.GetUFSession()
    print("[DOC] PutSolidInStlFile doc:", uf_session.Std.PutSolidInStlFile.__doc__)

if __name__ == "__main__":
    main()
