import os
import subprocess
from pathlib import Path

PRT_PATH = r"C:\Users\HP\nx-mcp\dog_leg_link.prt"
STL_PATH = r"C:\Users\HP\nx-mcp\dog_leg_link.stl"

nx_base = r"C:\Program Files\Siemens\NX2206"
nxbin = r"C:\Program Files\Siemens\NX2206\NXBIN"

env = os.environ.copy()
env["UGII_BASE_DIR"] = nx_base
env["UGII_ROOT_DIR"] = nxbin
env["PATH"] = f"{nxbin};{nx_base}\\UGII;{nx_base}\\STLXPORT;{env.get('PATH', '')}"

print("[INFO] Testing stlxport CLI options...")
res = subprocess.run([f"{nx_base}\\STLXPORT\\stlxport.exe"], shell=True, env=env, capture_output=True, text=True)
print("STLXPORT STDOUT:", res.stdout)
print("STLXPORT STDERR:", res.stderr)

res2 = subprocess.run([f"{nx_base}\\STLXPORT\\stlxport.exe", PRT_PATH, STL_PATH], shell=True, env=env, capture_output=True, text=True)
print("STLXPORT Run STDOUT:", res2.stdout)
print("STLXPORT Run STDERR:", res2.stderr)

print("Checking STL file exists:", Path(STL_PATH).exists())
