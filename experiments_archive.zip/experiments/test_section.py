r"""
test_section.py
"""
import NXOpen

session = NXOpen.Session.GetSession()
work_part = session.Parts.NewDisplay("C:/Users/HP/nx-mcp/test_section.prt", NXOpen.Part.Units.Millimeters)

p1 = NXOpen.Point3d(-7.0, 8.0, 0.0)
p2 = NXOpen.Point3d(-7.0, -8.0, 0.0)
p3 = NXOpen.Point3d(-27.0, 0.0, 0.0)

pt1 = work_part.Points.CreatePoint(p1)
pt2 = work_part.Points.CreatePoint(p2)
pt3 = work_part.Points.CreatePoint(p3)

l1 = work_part.Curves.CreateLine(pt1, pt2)
l2 = work_part.Curves.CreateLine(pt2, pt3)
l3 = work_part.Curves.CreateLine(pt3, pt1)

section = work_part.Sections.CreateSection(0.001, 0.01, 0.5)
help_point = NXOpen.Point3d(0.0, 0.0, 0.0)

for line in [l1, l2, l3]:
    rule = work_part.ScRuleFactory.CreateRuleCurveDumb([line])
    section.AddToSection([rule], line, NXOpen.NXObject.Null, NXOpen.NXObject.Null, help_point, NXOpen.Section.Mode.Create)

print("SUCCESS! Section element count:", section.GetElementCount())
