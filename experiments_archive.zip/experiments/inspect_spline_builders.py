import NXOpen
import sys

def main():
    print("NXOpen classes with Spline in name:")
    for attr in sorted(dir(NXOpen)):
        if "spline" in attr.lower():
            print("  ", attr)
            # Inspect methods of this class if it's a builder or class
            cls = getattr(NXOpen, attr)
            if isinstance(cls, type):
                print("    Methods:")
                for m in sorted(dir(cls)):
                    if not m.startswith("__"):
                        print("      ", m)

    print("\nFeatures classes with Spline in name:")
    if hasattr(NXOpen, "Features"):
        for attr in sorted(dir(NXOpen.Features)):
            if "spline" in attr.lower():
                print("  Features.", attr)
                cls = getattr(NXOpen.Features, attr)
                if isinstance(cls, type):
                    print("    Methods:")
                    for m in sorted(dir(cls)):
                        if not m.startswith("__"):
                            print("      ", m)

if __name__ == "__main__":
    main()
