import NXOpen
import sys

def main():
    session = NXOpen.Session.GetSession()
    part = session.Parts.NewDisplay("inspect_temp.prt", NXOpen.Part.Units.Millimeters)
    try:
        builder = part.Features.CreateStudioSplineBuilderEx(NXOpen.Features.Feature.Null)
        print("StudioSplineBuilderEx properties/methods:")
        for attr in sorted(dir(builder)):
            print("  ", attr)
        
        # Let's inspect ConstraintManager
        cm = builder.ConstraintManager
        print("\nConstraintManager properties/methods:")
        for attr in sorted(dir(cm)):
            print("  ", attr)
            
        # Let's inspect one of the constraint manager methods if possible
    finally:
        session.Parts.CloseAll(NXOpen.BasePart.CloseModified.CloseAfterSave, None)

if __name__ == "__main__":
    main()
