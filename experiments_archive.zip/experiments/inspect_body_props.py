import NXOpen
import sys

def main():
    try:
        session = NXOpen.Session.GetSession()
        part = session.Parts.NewDisplay("temp_body_inspect.prt", NXOpen.Part.Units.Millimeters)
        
        # Print NXOpen.Body attributes
        print("NXOpen.Body attributes:")
        for attr in dir(NXOpen.Body):
            if not attr.startswith("_"):
                print(attr)
                
        # Also print NXOpen.BodyType if it exists
        print("\nSearching NXOpen for BodyType:")
        for name in dir(NXOpen):
            if "Body" in name or "Solid" in name:
                print(name)
                
        # If there's NXOpen.Body.Type, let's print it
        if hasattr(NXOpen.Body, "Type"):
            print("\nBody Type attribute exists.")
            
    except Exception as e:
        print("Error:", e)

if __name__ == "__main__":
    main()
