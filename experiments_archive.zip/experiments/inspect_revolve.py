import NXOpen
import sys

def main():
    session = NXOpen.Session.GetSession()
    part = session.Parts.NewDisplay("inspect_temp_revolve.prt", NXOpen.Part.Units.Millimeters)
    try:
        builder = part.Features.CreateRevolveBuilder(NXOpen.Features.Feature.Null)
        print("RevolveBuilder properties/methods:")
        for attr in sorted(dir(builder)):
            print("  ", attr)
    finally:
        pass

if __name__ == "__main__":
    main()
