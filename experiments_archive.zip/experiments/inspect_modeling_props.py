import NXOpen
import NXOpen.UF
import sys

def main():
    try:
        session = NXOpen.Session.GetSession()
        uf_session = NXOpen.UF.UFSession.GetUFSession()
        
        print("Modeling.AskMassProps3d docs:")
        print(uf_session.Modeling.AskMassProps3d.__doc__)
        
    except Exception as e:
        print("Error:", e)

if __name__ == "__main__":
    main()
