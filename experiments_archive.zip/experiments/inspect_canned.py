import NXOpen
import sys

def main():
    try:
        # Inspect NXOpen.View.Canned values
        if hasattr(NXOpen.View, "Canned"):
            print("NXOpen.View.Canned attributes/values:")
            canned = NXOpen.View.Canned
            for attr in dir(canned):
                if not attr.startswith("_"):
                    print(attr)
        else:
            print("NXOpen.View.Canned does not exist.")
            
        # Search NXOpen for ViewScaleAdjustment or ScaleAdjustment
        print("\nSearching NXOpen for ScaleAdjustment or ViewScaleAdjustment:")
        for name in dir(NXOpen):
            if "ScaleAdjustment" in name or "ViewScale" in name or "Canned" in name:
                print(name)
                
        # If NXOpen.View.ScaleAdjustment exists, let's print it
        if hasattr(NXOpen.View, "ScaleAdjustment"):
            print("\nNXOpen.View.ScaleAdjustment attributes:")
            sa = NXOpen.View.ScaleAdjustment
            for attr in dir(sa):
                if not attr.startswith("_"):
                    print(attr)
                    
    except Exception as e:
        print("Error:", e)

if __name__ == "__main__":
    main()
