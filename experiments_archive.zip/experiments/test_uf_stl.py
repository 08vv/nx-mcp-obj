import NXOpen
import NXOpen.UF
from pathlib import Path

PRT_PATH = r"C:\Users\HP\nx-mcp\dog_leg_link.prt"
STL_PATH = r"C:\Users\HP\nx-mcp\dog_leg_link.stl"

def main():
    session = NXOpen.Session.GetSession()
    uf_session = NXOpen.UF.UFSession.GetUFSession()

    base_part, _ = session.Parts.OpenBaseDisplay(PRT_PATH)
    session.Parts.SetWork(base_part)
    work_part = session.Parts.Work

    bodies = list(work_part.Bodies)
    print(f"[INFO] Found {len(bodies)} bodies in work part.")

    if bodies:
        body = bodies[0]
        print(f"[INFO] Exporting STL for body {body.Tag} to {STL_PATH}...")
        try:
            # Set default STL params
            uf_session.Std.SetDefaultStlParams()
            
            # Open STL file (filename, False)
            file_handle = uf_session.Std.OpenTextStlFile(STL_PATH, False)
            
            # Put solid body into STL file: (fileHandle, csys=0, bodyTag, minEdgeLen, maxEdgeLen, facetToler)
            uf_session.Std.PutSolidInStlFile(file_handle, 0, body.Tag, 0.0, 0.0, 0.01)
            
            # Close STL file
            uf_session.Std.CloseStlFile(file_handle)
            print(f"[OK] STL exported successfully! Exists: {Path(STL_PATH).exists()}")
        except Exception as e:
            print(f"[ERROR] STL export failed: {e}")

if __name__ == "__main__":
    main()
