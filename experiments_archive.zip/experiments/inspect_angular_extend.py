import NXOpen
import sys

def main():
    session = NXOpen.Session.GetSession()
    part = session.Parts.NewDisplay("inspect_temp_revolve4.prt", NXOpen.Part.Units.Millimeters)
    try:
        builder = part.Features.CreateRevolveBuilder(NXOpen.Features.Feature.Null)
        limits = builder.Limits
        print("StartExtend type:", type(limits.StartExtend))
        print("StartExtend properties/methods:")
        for attr in sorted(dir(limits.StartExtend)):
            print("  ", attr)
    finally:
        pass

if __name__ == "__main__":
    main()
