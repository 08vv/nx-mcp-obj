import NXOpen
import sys

def main():
    try:
        session = NXOpen.Session.GetSession()
        part = session.Parts.NewDisplay("temp_curves_inspect.prt", NXOpen.Part.Units.Millimeters)
        
        print("part.Curves.CreateArc docs:")
        print(part.Curves.CreateArc.__doc__)
        
    except Exception as e:
        print("Error:", e)

if __name__ == "__main__":
    main()
