import json
import socket
import time
import os
import subprocess
from pathlib import Path

ROOT_DIR = Path("C:/Users/HP/nx-mcp").resolve()
PRT_PATH = str(ROOT_DIR / "dog_leg_link.prt")
STEP_PATH = str(ROOT_DIR / "dog_leg_link.stp")
STL_PATH = str(ROOT_DIR / "dog_leg_link.stl")

BRIDGE_PORT = 43210
BRIDGE_HOST = "127.0.0.1"

def main():
    print("[INFO] Terminating old ugraf processes...")
    os.system("taskkill /F /IM ugraf.exe 2>nul")
    time.sleep(2)

    config_path = ROOT_DIR / "live_bridge_config.json"
    config_path.write_text(json.dumps({"part_path": PRT_PATH, "port": BRIDGE_PORT}), encoding="utf-8")

    ugraf_exe = r"C:\Program Files\Siemens\NX2206\NXBIN\ugraf.exe"
    bridge_script = str(ROOT_DIR / "src" / "nx_mcp" / "bridge" / "nx_bridge.py")

    print("[INFO] Launching ugraf.exe with nx_bridge.py...")
    subprocess.Popen([ugraf_exe, f"-auto={bridge_script}"])

    print("[INFO] Waiting for socket connection...")
    sock = None
    start = time.time()
    while time.time() - start < 60:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(30)
            s.connect((BRIDGE_HOST, BRIDGE_PORT))
            sock = s
            print("[OK] Connected to NX Bridge!")
            break
        except Exception:
            time.sleep(2)

    if not sock:
        print("[ERROR] Could not connect to NX bridge socket.")
        return

    try:
        # Open part
        print(f"[INFO] Opening {PRT_PATH}...")
        payload = json.dumps({"tool": "open_part", "args": {"filepath": PRT_PATH}}) + "\n"
        sock.sendall(payload.encode("utf-8"))
        res = sock.recv(65536).decode("utf-8")
        print("open_part response:", res.strip())

        # Export STEP
        print(f"[INFO] Exporting STEP to {STEP_PATH}...")
        payload = json.dumps({"tool": "export_step", "args": {"output_path": STEP_PATH}}) + "\n"
        sock.sendall(payload.encode("utf-8"))
        res = sock.recv(65536).decode("utf-8")
        print("export_step response:", res.strip())

        # Export STL
        print(f"[INFO] Exporting STL to {STL_PATH}...")
        payload = json.dumps({"tool": "export_stl", "args": {"output_path": STL_PATH}}) + "\n"
        sock.sendall(payload.encode("utf-8"))
        res = sock.recv(65536).decode("utf-8")
        print("export_stl response:", res.strip())

        # Save part
        payload = json.dumps({"tool": "save_part", "args": {}}) + "\n"
        sock.sendall(payload.encode("utf-8"))
        res = sock.recv(65536).decode("utf-8")
        print("save_part response:", res.strip())

    finally:
        sock.close()
        # Clean config file
        if config_path.exists():
            config_path.unlink()

if __name__ == "__main__":
    main()
