import NXOpen
import sys

def main():
    session = NXOpen.Session.GetSession()
    part = session.Parts.NewDisplay("inspect_temp_pattern3.prt", NXOpen.Part.Units.Millimeters)
    try:
        builder = part.Features.CreatePatternFeatureBuilder(NXOpen.Features.Feature.Null)
        service = builder.PatternService
        rect = service.RectangularDefinition
        print("XDirection type:", type(rect.XDirection))
        print("XSpacing type:", type(rect.XSpacing))
        print("XSpacing properties/methods:")
        for attr in sorted(dir(rect.XSpacing)):
            print("  ", attr)
    finally:
        pass

if __name__ == "__main__":
    main()
