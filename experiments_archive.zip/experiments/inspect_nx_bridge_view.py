with open(r"c:\Users\HP\nx-mcp\src\nx_mcp\bridge\nx_bridge.py", "r", encoding="utf-8") as f:
    lines = f.readlines()

for i, line in enumerate(lines):
    if "def set_view" in line:
        print(f"Found set_view at line {i+1}")
        for j in range(max(0, i-2), min(len(lines), i+25)):
            print(f"  {j+1}: {lines[j].strip()}")
        break
