Set shell = CreateObject("WScript.Shell")
shell.Run """C:\Program Files\Siemens\NX2206\NXBIN\ugs_router.exe"" -ug -use_file_dir ""C:\Users\HP\nx-mcp\dog_leg_link.prt""", 0, False
