import NXOpen
import sys

def main():
    session = NXOpen.Session.GetSession()
    part = session.Parts.NewDisplay("inspect_temp_revolve3.prt", NXOpen.Part.Units.Millimeters)
    try:
        builder = part.Features.CreateRevolveBuilder(NXOpen.Features.Feature.Null)
        limits = builder.Limits
        print("AngularLimits properties/methods:")
        for attr in sorted(dir(limits)):
            print("  ", attr)
    finally:
        pass

if __name__ == "__main__":
    main()
