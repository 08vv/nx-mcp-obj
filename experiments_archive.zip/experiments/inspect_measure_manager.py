import NXOpen
import sys

def main():
    try:
        session = NXOpen.Session.GetSession()
        part = session.Parts.NewDisplay("temp_measure_inspect.prt", NXOpen.Part.Units.Millimeters)
        
        # Print attributes of part.MeasureManager
        print("part.MeasureManager class:", part.MeasureManager.__class__.__name__)
        print("\npart.MeasureManager attributes:")
        for attr in dir(part.MeasureManager):
            if not attr.startswith("_"):
                print(attr)
                
    except Exception as e:
        print("Error:", e)

if __name__ == "__main__":
    main()
