import NXOpen
import sys

def main():
    session = NXOpen.Session.GetSession()
    part = session.Parts.NewDisplay("inspect_temp_revolve2.prt", NXOpen.Part.Units.Millimeters)
    try:
        builder = part.Features.CreateRevolveBuilder(NXOpen.Features.Feature.Null)
        print("Default Axis value:", builder.Axis)
        
        # Create an Axis object
        axis_obj = part.Axes.CreateAxis(
            NXOpen.Point3d(0.0, 0.0, 0.0),
            NXOpen.Vector3d(0.0, 0.0, 1.0),
            NXOpen.SmartObject.UpdateOption.WithinModeling
        )
        print("Created Axis type:", type(axis_obj))
        
        try:
            builder.Axis = axis_obj
            print("Assigned successfully! New Axis value:", builder.Axis)
        except Exception as e:
            print("Assignment failed:", e)
    finally:
        pass

if __name__ == "__main__":
    main()
